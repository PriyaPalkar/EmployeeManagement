package CRUD.EmployeeRecords.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import CRUD.EmployeeRecords.Entity.Employee;

public interface EmployeeRepository extends JpaRepository <Employee, Long>{

}
